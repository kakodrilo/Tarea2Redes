Laboratorio 2
---------------------
integrantes:
-> Joaquín Castillo Tapia    201773520-1
-> María Paz Morales Llopis  201773505-8
---------------------
Consideraciones:
** Al iniciar la simulación en Packet Tracer la generación y  la distribución de tablas demora un tiempo, por lo que si se envía un mensaje antes
de que el proceso finalice, el mensaje fallará y será necesario enviarlo de nuevo.